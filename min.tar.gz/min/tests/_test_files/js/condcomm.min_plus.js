var isWin;
/*@cc_on
    @if (@_win32)
        isWin = true;
    @else @*/
        isWin = false;
   /*@end
@*/

var recognizesCondComm = true;
//@cc_on/*
recognizesCondComm = false;
//@cc_on*/