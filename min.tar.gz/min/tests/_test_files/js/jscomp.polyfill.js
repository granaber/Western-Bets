(function() {
    /**
     * @type {string}
     */
    var $array = jQuery.find('#div');
    print($array.find('a'));
})();