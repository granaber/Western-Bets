
/* url.in.js */

/* 1  */ foo; /* http://example.com */
/* 2  */ bar;
/* 3  */
/* 4  */ foo; /*
/* 5  *|     http://example.com */
/* 6  */ bar;
/* 7  */
/* 8  */ foo = "http://example.com"; /* hello */
/* 9  */ bar;
/* 10 */
/* 11 */ foo = "http://example.com"; /*
/* 12 *| hello */
/* 13 */ bar;
/* 14 */
