foo; /* http://example.com */
bar;

foo; /*
    http://example.com */
bar;

foo = "http://example.com"; /* hello */
bar;

foo = "http://example.com"; /*
hello */
bar;
