<?php

return array(
    'css' => array(
        '//_test_files/css/paths_prepend.css',
        '//_test_files/css/styles.css',
    ),

    'less' => array(
        '//_test_files/main.less',
    ),

    'scss' => array(
        '//_test_files/main.scss',
    ),
);
